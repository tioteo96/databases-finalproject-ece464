package com.packet.indoor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IndoorApplicationTests {

	@Test
	void contextLoads() {
	}

}
